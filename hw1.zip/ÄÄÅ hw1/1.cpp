#include <iostream>

int cubeV(int x);

int main()
{
	cout << cubeV(256); 
	return 0;
}


int cubeV(int x)
	return x * x * x;

